using System;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Description;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;

[DataContract]
public class Message
    {
        public Message(int time, int from, int to, int tok, int pay)
        {
            this.Time = time;
            this.From = from;
            this.To = to;
            this.Tok = tok;
			this.Pay = pay;
			//this.Parent = parent;
        }

        private int time;
		[DataMember]
        public int Time
        {
            get { return time; }
            set { time = value; }
        }
        private int from;
		[DataMember]
        public int From
        {
            get { return from; }
            set { from = value; }
        }
        private int to;
		[DataMember]
        public int To
        {
            get { return to; }
            set { to = value; }
        }
        private int tok;
		[DataMember]
        public int Tok
        {
            get { return tok; }
            set { tok = value; }
        }
		private int pay;
		[DataMember]
        public int Pay
        {
            get { return pay; }
            set { pay = value; }
        }
		/* private int parent;

        public int Parent
        {
            get { return parent; }
            set { parent = value; }
        } */
    }

[ServiceContract()]
public interface INodeService {
   [OperationContract(IsOneWay=true)]
    [WebInvoke(RequestFormat=WebMessageFormat.Json,ResponseFormat=WebMessageFormat.Json)]
   void Messages(List<Message> mq);
}
