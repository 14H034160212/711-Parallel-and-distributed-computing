using System;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Description;
using System.Threading;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;

[ServiceBehavior(IncludeExceptionDetailInFaults=true,
    InstanceContextMode=InstanceContextMode.PerCall,
    ConcurrencyMode=ConcurrencyMode.Single)]
public class PongService : INodeService {
    public static AutoResetEvent Done = new AutoResetEvent (false);
    
	public static int timeCount = 0;
	
    public static Func<int> Tid = () => Thread.CurrentThread.ManagedThreadId;
    
    public static Func<double> Millis = () => DateTime.Now.TimeOfDay.TotalMilliseconds;
  
	public static List<Message> list = new List<Message>();
	
	public static Dictionary<String, String> dict_loop = new Dictionary<String, String>();
    
    public void Messages (List<Message> mq) {
        WebChannelFactory<INodeService> wcf = null;
        OperationContextScope scope = null;
		
		
		var str = "config4.txt";
			
			Dictionary<String, String> dict = new Dictionary<String, String>();
			
			int num = NodeNum(dict);
			PongService hws = new PongService();
			
			
			dict = hws.ReadFile(str);
			
			
			
         foreach(Message m in mq){
				list.Add(m);
		 }
		 for(int i=0;i<list.Count;i++){
			 String s1 = list[i].From+"";
			 String s2 = list[i].To+"";
			 String s3 = s1+"-"+s2;
			 if(dict.ContainsKey(s3)&&(!dict_loop.ContainsKey(s3))){
						 Console.Error.WriteLine ($"... {list[i].Time} 0 < {list[i].From} {list[i].To} {list[i].Tok} {list[i].Pay}");
						Console.WriteLine ($"... {list[i].Time} 0 < {list[i].From} {list[i].To} {list[i].Tok} {list[i].Pay}");
						list[i].Time = list[i].Time + int.Parse(dict[s3]);
						dict_loop.Add(s3, "1");
			 }
			 if((!dict.ContainsKey(s3))&&(!dict_loop.ContainsKey(s3)))
			 {
				 Console.Error.WriteLine ($"... {list[i].Time} 0 < {list[i].From} {list[i].To} {list[i].Tok} {list[i].Pay}");
				Console.WriteLine ($"... {list[i].Time} 0 < {list[i].From} {list[i].To} {list[i].Tok} {list[i].Pay}");
				 list[i].Time = list[i].Time + int.Parse(dict["-"]);
				 dict_loop.Add(s3, "1");
			 }
			 
		 }
		 
		 list.Sort(new IcpTime());
		 String destination = list[0].To + "";
		 try{
			//Load the config4.txt into the dictionary
			
			//Open the all nodes' posts
			/* foreach (KeyValuePair<String, String> kvp in dict){
				if(kvp.Key == destination){ */
				var uri = new Uri ($"http://localhost:{dict[destination]}");
						wcf = new WebChannelFactory<INodeService> (uri);
						var channel = wcf.CreateChannel ();

						scope = new OperationContextScope ((IContextChannel)channel);
						 /* using (var wcf = 
					new WebChannelFactory<INodeService>(new Uri("http://localhost:{kvp.Value}/"))) {
						var channel = wcf.CreateChannel(); */
						
							String s1 = list[0].From+"";
							String s2 = list[0].To+"";
							String s3 = s1+"-"+s2;
									
							/* foreach (KeyValuePair<String, String> kvp2 in dict){								
									if(kvp2.Key == s3){ */
							if(dict.ContainsKey(s3)){
										
										//Thread.Sleep(int.Parse(dict[s3]));
										timeCount = list[0].Time;
										Console.Error.WriteLine ($"... {timeCount} 0\t> {list[0].From} {list[0].To} {list[0].Tok} {list[0].Pay} ");
										Console.WriteLine ($"... {timeCount} 0\t> {list[0].From} {list[0].To} {list[0].Tok} {list[0].Pay} ");
										if(list[0].To==0&&list[0].Tok==2){
											var msg = ($"All Done:Payload={list[0].Pay}!");
											Console.Error.WriteLine (msg);
											Console.WriteLine (msg);
											Done.Set ();
										}else{
											List<Message> list_Message = new List<Message>();
											Message m1 = new Message(timeCount, list[0].From, list[0].To, list[0].Tok, list[0].Pay);
											list_Message.Add(m1);
											channel.Messages (list_Message);	
										}
							}else{
							
								/* foreach (KeyValuePair<String, String> kvp3 in dict){								
									if(kvp3.Key == "-"){ */
										//String s4 = "-";
										
										//Console.WriteLine ($"dict['-']");
										
										if(list[0].From == 1 && list[0].To == 0){
										//		Thread.Sleep(int.Parse(dict[s4]));
											/* 	Console.Error.WriteLine ($"... {Millis():F0} 0\t> {from} {to} {tok} {pay}");
												Console.WriteLine ($"... {Millis():F0} 0\t> {from} {to} {tok} {pay}"); */
										}else{
												//Thread.Sleep(int.Parse(dict[s4]));
												timeCount = list[0].Time;
												Console.Error.WriteLine ($"... {timeCount} 0\t> {list[0].From} {list[0].To} {list[0].Tok} {list[0].Pay} ");
												Console.WriteLine ($"... {timeCount} 0\t> {list[0].From} {list[0].To} {list[0].Tok} {list[0].Pay} ");
										}
										
										if(list[0].To==0&&list[0].Tok==2){
											var msg = ($"All Done: Time= {timeCount}, Payload= {list[0].Pay}!");
											Console.Error.WriteLine (msg);
											Console.WriteLine (msg);
											Done.Set ();
										}else{
											List<Message> list_Message_1 = new List<Message>();
											Message m2 = new Message(timeCount, list[0].From, list[0].To, list[0].Tok, list[0].Pay);
											list_Message_1.Add(m2);							
											channel.Messages (list_Message_1);	
										}
								
							}
					
			list.Remove(list[0]);
			
         } catch (Exception ex) {
            var msg = ($"*** Exception {ex.Message}");
            Console.Error.WriteLine (msg);
            Console.WriteLine (msg);
            wcf = null;
            scope = null;
        
        } finally {
            if (wcf != null) ((IDisposable)wcf).Dispose();
            if (scope != null) ((IDisposable)scope).Dispose();
        } 
    }
	
	
	//Load the config4.txt into the dictionary
	public Dictionary<String, String> ReadFile(string name) {
		Dictionary<String, String> dict = new Dictionary<String, String>();
		try{
		StreamReader file = new StreamReader(name);
		String line="// String";
		while((line = file.ReadLine()) != null){
			
			if(!line.StartsWith("//")){
				if(!String.IsNullOrEmpty(line)){
			
					String[] sArr = Regex.Split(line, "\\s+", RegexOptions.IgnoreCase);
		
					dict.Add(sArr[0], sArr[1]);		
				}				
			} 
			
		}
		
		file.Close();
		return dict;	
		}catch(Exception e){
			Console.WriteLine($"*** Exception {e.Message}");
			return dict;	
		}
		
    }
	
	public static int NodeNum (Dictionary<String, String> dict){
		int count = 0;
		foreach (KeyValuePair<String, String> kvp in dict){
				if(!kvp.Key.Contains("-")&&kvp.Key != "0"){
					count++;
				}
			}
		return count;
			
	}
}

	
	
	public class IcpTime : IComparer<Message>
    {
        
        public int Compare(Message x, Message y)
        {
            return x.Time.CompareTo(y.Time);
        }
    }

public class arc {
	public static Func<double> Millis = () => DateTime.Now.TimeOfDay.TotalMilliseconds;
	
    public static void Main (string[] args) {
        WebServiceHost host = null;

        try {
            WebChannelFactory<INodeService> wcf = null;
			OperationContextScope scope = null;
		
			//Load the config4.txt into the dictionary
			var str = "config4.txt";
			
			Dictionary<String, String> dict = new Dictionary<String, String>();
			
			PongService ps = new PongService();
			
			dict = ps.ReadFile(str);
			
			/* foreach (KeyValuePair<String, String> kvp in dict){
				Console.WriteLine ($"kvp={kvp.Key}, value={kvp.Value}");
			} */
			//Open the all nodes' posts
			/* foreach (KeyValuePair<String, String> kvp in dict){
				if(kvp.Key == "0"){ */
					//Console.WriteLine ("http://localhost:{kvp.Value}/");
					var baseAddress = new Uri($"http://localhost:{dict["0"]}");
						host = new WebServiceHost (typeof(PongService), baseAddress);
						ServiceEndpoint ep = host.AddServiceEndpoint (typeof(INodeService), new WebHttpBinding(), "");

						host.Open();

						// http://localhost:8081/Pong?ttl=7
						var msg = ($"Arc=0:{baseAddress}/Message?from=?,to=?,tok=?,payload=?");
						Console.Error.WriteLine (msg);
						Console.WriteLine (msg);
						
						
						/* foreach (KeyValuePair<String, String> kvp2 in dict){
							if(kvp2.Key == "1"){ */
								var uri = new Uri ($"http://localhost:{dict["1"]}");
								wcf = new WebChannelFactory<INodeService> (uri);
								var channel = wcf.CreateChannel ();

								scope = new OperationContextScope ((IContextChannel)channel);
								Console.Error.WriteLine ($"... 0 0\t> 0 1 1 0");
								Console.WriteLine ($"... 0 0\t> 0 1 1 0");
								List<Message> list_host = new List<Message>();
								Message m_host = new Message(0, 0, 1, 1, 0);
								list_host.Add(m_host);
								channel.Messages(list_host);	
										
						/* 	}
						}	 */
						
									
						//Console.Error.WriteLine ("Press <Enter> to stop the service.");
						//Console.ReadLine ();
					
			/* 	}
			} */

					PongService.Done.WaitOne ();

						host.Close ();
			
        
        } catch (Exception ex) {
            var msg = ($"*** Exception {ex.Message}");
            Console.Error.WriteLine (msg);
            Console.WriteLine (msg);
            host = null;
        
        } finally {
            if (host != null) ((IDisposable)host).Dispose();
        }
    }
}

