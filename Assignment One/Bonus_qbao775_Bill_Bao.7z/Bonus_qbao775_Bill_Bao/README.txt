Dear Marker,

You can copy the arc.cs, node.cs and interface.cs into your test file folder. The interface.cs has been modified. Thank you so much.

Have a great day,
Bill Bao