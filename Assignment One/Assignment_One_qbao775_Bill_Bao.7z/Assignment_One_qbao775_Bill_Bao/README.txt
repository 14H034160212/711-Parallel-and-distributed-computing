Dear Marker,

You can copy the arc.cs and node.cs into your test file folder. The interface.cs is just same with the default interface.cs.

Have a great day,
Bill Bao