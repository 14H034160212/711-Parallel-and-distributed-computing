using System;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Description;
using System.Threading;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;

[ServiceBehavior(IncludeExceptionDetailInFaults=true,
    InstanceContextMode=InstanceContextMode.PerCall,
    ConcurrencyMode=ConcurrencyMode.Single)]
public class PingService : INodeService {
    public static AutoResetEvent Done = new AutoResetEvent (false);
	
	public static String Parent = null;
	
	public static int rec = 0;
	
   // public static int count = 3;
	
	public static int address = 0;
	
	public static int count = 0;
	
    public static Func<int> Tid = () => Thread.CurrentThread.ManagedThreadId;
    
    public static Func<double> Millis = () => DateTime.Now.TimeOfDay.TotalMilliseconds;
    
	public void setInitial (int from){
		address = from;
	}
	
	public static void SendMessage (int from, int to, int tok, int pay) {
        WebChannelFactory<INodeService> wcf2 = null;
        OperationContextScope scope2 = null; 
		
		
		try{
		
        //Load the config4.txt into the dictionary
			var str = "config4.txt";
			
			Dictionary<String, String> dict = new Dictionary<String, String>();
			
			PingService hws = new PingService();
			
			dict = hws.ReadFile(str);
			
					var uri2 = new Uri ($"http://localhost:{dict["0"]}");
					wcf2 = new WebChannelFactory<INodeService> (uri2);
					var channel2 = wcf2.CreateChannel ();

					scope2 = new OperationContextScope ((IContextChannel)channel2); 
					Console.Error.WriteLine ($"... {Millis():F0} {from} \t> {from} {to} {tok} {pay}");
					Console.WriteLine ($"... {Millis():F0} {from} \t> {from} {to} {tok} {pay}");
					
					channel2.Message(from, to, tok, pay);	
					
			
			
		}catch (Exception ex) {
            var msg = ($"*** Exception {ex.Message}");
            Console.Error.WriteLine (msg);
            Console.WriteLine (msg);
            wcf2 = null;
            scope2 = null;
        
        } finally {
            if (wcf2 != null) ((IDisposable)wcf2).Dispose();
            if (scope2 != null) ((IDisposable)scope2).Dispose();
        } 
			
    }
	
	public static void ReceiveMessage (int from, int to, int tok, int pay) {
        
		String[] names = Environment.GetCommandLineArgs();
		if(pay > 0){
			count = count + pay;
		}
			if(Parent == null){
				
				Parent = from+"";
				Console.Error.WriteLine ($"... {Millis():F0} {to} < {from} {to} {tok} {pay} *");
				Console.WriteLine ($"... {Millis():F0} {to} < {from} {to} {tok} {pay} *");
				for(int k = 3;k < names.GetLength(0);k++){					
						if(int.Parse(names[k]) != int.Parse(Parent)){
							//count++;
							SendMessage(to, int.Parse(names[k]), tok, pay);
						}						
						
					}
			}
			else{
				Console.Error.WriteLine ($"... {Millis():F0} {to} < {from} {to} {tok} {pay}");
				Console.WriteLine ($"... {Millis():F0} {to} < {from} {to} {tok} {pay}");		
			}
		
			if(to == int.Parse(names[2])){
					rec++;
						//Console.WriteLine ($"names[2]:{rec}");
			}
			
			if((rec == (names.GetLength(0)-3))&&(names[2] != "1")){
					//Console.Error.WriteLine ($"rec = {rec}");
					//Console.WriteLine ($"rec = {rec}");
					SendMessage(int.Parse(names[2]), int.Parse(Parent), 2, count+1);
					var msg = ($"Node={names[2]}:Parent={Parent},Payload={count+1}!");
					Console.Error.WriteLine (msg);
					Console.WriteLine (msg);
					Done.Set ();
				
			}
			
			if((rec == (names.GetLength(0)-2))&&(names[2] == "1")){
				
				SendMessage(int.Parse(names[2]), int.Parse(Parent), 2, count+1);
				var msg = ($"Node={names[2]}:Parent={Parent},Payload={count+1}!");
				Console.Error.WriteLine (msg);
				Console.WriteLine (msg);
				Done.Set ();
			}
		
			
    }
	
    public void Message (int from, int to, int tok, int pay) {
        
        String[] names = Environment.GetCommandLineArgs();
		
					if(to == int.Parse(names[2])){
						ReceiveMessage(from, to, tok, pay);
					}
		
    }
	
	//Load the config4.txt into the dictionary
	public Dictionary<String, String> ReadFile(string name) {
		Dictionary<String, String> dict = new Dictionary<String, String>();
		try{
		StreamReader file = new StreamReader(name);
		String line="// String";
		while((line = file.ReadLine()) != null){
			
			if(!line.StartsWith("//")){
				if(!String.IsNullOrEmpty(line)){
			
					String[] sArr = Regex.Split(line, "\\s+", RegexOptions.IgnoreCase);
		
					dict.Add(sArr[0], sArr[1]);		
				}				
			} 
			
		}
		
		file.Close();
		return dict;	
		}catch(Exception e){
			Console.WriteLine($"*** Exception {e.Message}");
			return dict;	
		}
		
    }
}




public class node {
    public static void Main (string[] args) {
        WebServiceHost host = null;

        try {
			String[] names = Environment.GetCommandLineArgs();
			//int initial = int.Parse(names[2]);
			
			//Load the config4.txt into the dictionary
			var str = "config4.txt";
			
			Dictionary<String, String> dict = new Dictionary<String, String>();
			
			PingService hws = new PingService();
			
			dict = hws.ReadFile(str);
			
			
			//Open the all nodes' posts
			
				//String str1 = dict[names[2]];
				
					var baseAddress = new Uri($"http://localhost:{dict[names[2]]}");
					host = new WebServiceHost (typeof(PingService), baseAddress);
					ServiceEndpoint ep = host.AddServiceEndpoint (typeof(INodeService), new WebHttpBinding(), "");

					host.Open();

					// http://localhost:8080/ping?ttl=7
					var msg = ($"Node={names[2]}:{baseAddress}Message?from=?,to=?,tok=?,payload=?");
					Console.Error.WriteLine (msg);
					Console.WriteLine (msg);
					
					//PingService.SendPong ("0", "1", 1, 0);
				
					PingService.Done.WaitOne ();

					host.Close ();
			
        } catch (Exception ex) {
            var msg = ($"*** Exception {ex.Message}");
            Console.Error.WriteLine (msg);
            Console.WriteLine (msg);
            host = null;
        
        } finally {
            if (host != null) ((IDisposable)host).Dispose();
        }
    }
}

